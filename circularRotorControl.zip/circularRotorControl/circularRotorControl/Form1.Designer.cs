﻿namespace circularRotorControl
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.theCircularRotorControl8 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl7 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl6 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl5 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl4 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl3 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl2 = new circularRotorControl.theCircularRotorControl();
            this.theCircularRotorControl1 = new circularRotorControl.theCircularRotorControl();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // theCircularRotorControl8
            // 
            this.theCircularRotorControl8.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl8.Location = new System.Drawing.Point(171, 67);
            this.theCircularRotorControl8.Name = "theCircularRotorControl8";
            this.theCircularRotorControl8.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl8.TabIndex = 7;
            // 
            // theCircularRotorControl7
            // 
            this.theCircularRotorControl7.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl7.Location = new System.Drawing.Point(124, 67);
            this.theCircularRotorControl7.Name = "theCircularRotorControl7";
            this.theCircularRotorControl7.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl7.TabIndex = 6;
            // 
            // theCircularRotorControl6
            // 
            this.theCircularRotorControl6.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl6.Location = new System.Drawing.Point(77, 67);
            this.theCircularRotorControl6.Name = "theCircularRotorControl6";
            this.theCircularRotorControl6.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl6.TabIndex = 5;
            // 
            // theCircularRotorControl5
            // 
            this.theCircularRotorControl5.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl5.Location = new System.Drawing.Point(30, 67);
            this.theCircularRotorControl5.Name = "theCircularRotorControl5";
            this.theCircularRotorControl5.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl5.TabIndex = 4;
            // 
            // theCircularRotorControl4
            // 
            this.theCircularRotorControl4.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl4.Location = new System.Drawing.Point(396, 67);
            this.theCircularRotorControl4.Name = "theCircularRotorControl4";
            this.theCircularRotorControl4.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl4.TabIndex = 3;
            // 
            // theCircularRotorControl3
            // 
            this.theCircularRotorControl3.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl3.Location = new System.Drawing.Point(349, 67);
            this.theCircularRotorControl3.Name = "theCircularRotorControl3";
            this.theCircularRotorControl3.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl3.TabIndex = 2;
            // 
            // theCircularRotorControl2
            // 
            this.theCircularRotorControl2.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl2.Location = new System.Drawing.Point(302, 67);
            this.theCircularRotorControl2.Name = "theCircularRotorControl2";
            this.theCircularRotorControl2.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl2.TabIndex = 1;
            // 
            // theCircularRotorControl1
            // 
            this.theCircularRotorControl1.BackColor = System.Drawing.Color.White;
            this.theCircularRotorControl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theCircularRotorControl1.Location = new System.Drawing.Point(255, 67);
            this.theCircularRotorControl1.Name = "theCircularRotorControl1";
            this.theCircularRotorControl1.Size = new System.Drawing.Size(40, 25);
            this.theCircularRotorControl1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "yyyy";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "mm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(124, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "ww";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(171, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "ddd";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(255, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "hh";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(302, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "mm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(349, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "ss";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(396, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "ms";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 118);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.theCircularRotorControl8);
            this.Controls.Add(this.theCircularRotorControl7);
            this.Controls.Add(this.theCircularRotorControl6);
            this.Controls.Add(this.theCircularRotorControl5);
            this.Controls.Add(this.theCircularRotorControl4);
            this.Controls.Add(this.theCircularRotorControl3);
            this.Controls.Add(this.theCircularRotorControl2);
            this.Controls.Add(this.theCircularRotorControl1);
            this.Name = "Form1";
            this.Text = "circulare rotor control test";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private theCircularRotorControl theCircularRotorControl1;
        private theCircularRotorControl theCircularRotorControl2;
        private theCircularRotorControl theCircularRotorControl3;
        private theCircularRotorControl theCircularRotorControl4;
        private theCircularRotorControl theCircularRotorControl5;
        private theCircularRotorControl theCircularRotorControl6;
        private theCircularRotorControl theCircularRotorControl7;
        private theCircularRotorControl theCircularRotorControl8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;


    }
}

